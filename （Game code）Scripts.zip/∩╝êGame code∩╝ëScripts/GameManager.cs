using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static  class GameManager 
{

    public static int PlayerHP = 15;
    public static int Scoer = 0;
    public static int SuiPian = 0;

  
}
